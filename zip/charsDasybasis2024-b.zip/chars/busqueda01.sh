tnt  mxram 500 \; p $1.mtr \; log $1.out \;  taxn = \;  hold 25000 \;  xmult = rep 20000 \; nel* \; export -$1.e.tre \; ttag= \; resample rep 10000 \; export -$1.boot.e.tre \; ttag - \;  piwe = 3 \; hold 0 \; hold 25000 \;  xmult = rep 20000 \; nel* \; export -$1.p3.tre \; ttag= \; resample rep 10000 \; export -$1.boot.p3.tre \; zz 

