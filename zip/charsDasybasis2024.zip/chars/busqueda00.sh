tnt  mxram 500 \; p DasybasisMorphology2015.mtr \; hold 10000 \; piwe = 3 \;xmult = rep 2500 \;
