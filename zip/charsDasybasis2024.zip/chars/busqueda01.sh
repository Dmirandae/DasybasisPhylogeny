tnt  mxram 500 \; p DasybasisMorphology2015.mtr \; log verpiwe3.out \;   hold 100000 \; piwe = 3 \;xmult = rep 25000 \; taxn = \; nel* \; export -DasybasisPiwe3.tre \; resample rep 10000 \; zz 
