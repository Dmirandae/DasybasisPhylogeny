tnt  mxram 500 \; p DasybasisMorphology2015.mtr \; hold 100000 \; piwe = 3 \;xmult = rep 25000 \;
